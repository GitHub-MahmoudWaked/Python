from django.apps import AppConfig


class FavBooksConfig(AppConfig):
    name = 'fav_books'
